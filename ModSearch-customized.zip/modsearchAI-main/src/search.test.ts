import * as fs from 'fs';
import * as path from 'path';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { ModsearchConfig } from './config.ts';
import {
  buildCooldownController,
  cooldownStateKey,
  emptyCooldownState,
  loadCooldownState,
  recordQuotaCooldown,
} from './cooldown.ts';
import {
  type EngineAttempt,
  noEngineMessage,
  resolveMode,
  runSearch,
  validateUrl,
} from './search.ts';
import { agyQuotaEnvelope, agySearchEnvelope } from './fixtures/index.ts';
import { findEngine, type SearchEngine } from './providers/index.ts';
import {
  BARE_ENV,
  cleanupTempDirs,
  fakeEngine,
  SPAWNS_FAKE_CLI,
  startLocalPage,
  tempDir,
  withSignedInGrok,
} from './testing/helpers.ts';

// Suites and cases that spawn a fake engine CLI cannot run on Windows, where a
// non-.exe fake is not a runnable image under modsearch's no-shell spawn. They
// are gated here and skipped there; see SPAWNS_FAKE_CLI in testing/helpers.ts.
const describeSpawn = describe.runIf(SPAWNS_FAKE_CLI);
const itSpawn = it.runIf(SPAWNS_FAKE_CLI);

/**
 * A config whose agy engine is the given fake binary (full path, so PATH is
 * irrelevant). The engine is pinned to agy: the fake is the engine under test,
 * and without the pin the default chain leads with keyless firecrawl, whose
 * network attempt would make these unit tests flaky and online.
 */
function agyConfig(
  fake: { stdout?: string; code?: number; delaySeconds?: number },
  extra: ModsearchConfig = {},
): ModsearchConfig {
  const bin = fakeEngine({ name: 'agy', ...fake });
  return {
    engine: 'antigravity-cli',
    ...extra,
    engines: { ...extra.engines, 'antigravity-cli': { bin } },
  };
}

describe('mode resolution', () => {
  it('is search for a query, fetch for a url', () => {
    expect(resolveMode('latest node lts', undefined)).toBe('search');
    expect(resolveMode(undefined, 'https://example.com')).toBe('fetch');
    expect(resolveMode('pricing', 'https://example.com')).toBe('fetch');
  });

  it('rejects runs with neither', () => {
    expect(() => resolveMode(undefined, undefined)).toThrow('Provide a search query');
  });

  it('validates fetch urls', () => {
    expect(validateUrl(' https://example.com/a ')).toBe('https://example.com/a');
    expect(() => validateUrl('ftp://example.com')).toThrow('must start with http');
  });
});

describe('zero-config machine', () => {
  beforeEach(() => {
    vi.stubEnv('http_proxy', '');
    vi.stubEnv('https_proxy', '');
    vi.stubEnv('HTTP_PROXY', '');
    vi.stubEnv('HTTPS_PROXY', '');
    vi.stubEnv('no_proxy', '');
    vi.stubEnv('NO_PROXY', '');
  });

  afterEach(() => {
    cleanupTempDirs();
    vi.unstubAllEnvs();
  });

  it('searches through keyless firecrawl on a bare machine, failing honestly offline', async () => {
    // Nothing installed, no keys, no config file: keyless firecrawl is the
    // floor, so search is attempted rather than refused. Stub fetch so the
    // unit test stays offline; the stubbed network failure must come back as
    // an engine failure, not a crash.
    vi.stubGlobal('fetch', async () => {
      throw new Error('offline unit test');
    });
    try {
      await expect(
        runSearch({ query: 'anything', config: {}, env: BARE_ENV, timeoutMs: 5_000 }),
      ).rejects.toThrow(/Every engine for the web source failed/);
    } finally {
      vi.unstubAllGlobals();
    }

    const message = noEngineMessage('search');
    expect(message).toContain('antigravity-cli:');
    expect(message).toContain('tavily:');
  });

  it('still fetches a page with nothing installed', async () => {
    // The local engine needs no setup, so -u works out of the box. Point it at a
    // local server rather than the internet: unit tests stay offline.
    const page = await startLocalPage('<html><body><h1>Example Domain</h1></body></html>');
    try {
      const result = await runSearch({
        url: page.url,
        config: { allowPrivateNetwork: true },
        env: BARE_ENV,
        timeoutMs: 30_000,
      });
      expect(result.results).toHaveLength(1);
      expect(result.results[0].engine).toBe('local');
      expect(String(result.results[0].content)).toContain('Example Domain');
    } finally {
      await page.close();
    }
  }, 40_000);

  itSpawn(
    'always returns an array of results, one per source',
    async () => {
      const config = agyConfig({ stdout: agySearchEnvelope('web-sum') });
      const result = await runSearch({
        query: 'node lts',
        config,
        env: BARE_ENV,
        timeoutMs: 20_000,
      });
      expect(result.results).toHaveLength(1);
      expect(result.results[0]).toMatchObject({
        source: 'web',
        engine: 'antigravity-cli',
        summary: 'web-sum',
      });
      expect(result.mode).toBe('search');
    },
    30_000,
  );

  itSpawn(
    'falls through to the next engine and says so',
    async () => {
      const page = await startLocalPage('<html><body><p>fallback body</p></body></html>');
      try {
        const config = agyConfig({ code: 1 }, { allowPrivateNetwork: true });
        const result = await runSearch({
          url: page.url,
          config,
          env: BARE_ENV,
          timeoutMs: 30_000,
        });
        expect(result.results[0].engine).toBe('local');
        expect((result.results[0].warnings as string[]).join(' ')).toContain('Fell back to local');
      } finally {
        await page.close();
      }
    },
    40_000,
  );
});

describe('per-engine API key rotation', () => {
  afterEach(() => {
    vi.unstubAllGlobals();
    vi.restoreAllMocks();
  });

  it.each([401, 403, 429])(
    'tries comma-separated keys in order after a key-related HTTP %i failure',
    async (status) => {
      const sentKeys: string[] = [];
      vi.stubGlobal(
        'fetch',
        vi.fn(async (_url: string, init: RequestInit) => {
          sentKeys.push((init.headers as Record<string, string>)['x-api-key']);
          if (sentKeys.length === 1) {
            return {
              ok: false,
              status,
              statusText: 'Key failure',
              text: async () => 'invalid API key',
            } as Response;
          }
          return {
            ok: true,
            status: 200,
            statusText: 'OK',
            json: async () => ({ results: [] }),
            text: async () => '{}',
          } as Response;
        }),
      );

      const result = await runSearch({
        query: 'q',
        engine: 'exa',
        config: { engines: { exa: { apiKey: ' first-key, ,second-key ' } } },
        env: BARE_ENV,
        timeoutMs: 20_000,
      });

      expect(sentKeys).toEqual(['first-key', 'second-key']);
      expect(result.results[0].attempts).toMatchObject([
        { engine: 'exa', keyIndex: 0, ok: false },
        { engine: 'exa', keyIndex: 1, ok: true },
      ]);
      expect(result.results[0].warnings.join(' ')).toContain('Rotated to exa API key 2');
      expect(result.results[0].warnings.join(' ')).not.toContain('Fell back to exa');
    },
  );

  it('does not try another key after a network failure', async () => {
    const fetchMock = vi.fn(async () => {
      throw new Error('network unavailable');
    });
    vi.stubGlobal('fetch', fetchMock);

    await expect(
      runSearch({
        query: 'q',
        engine: 'exa',
        config: { engines: { exa: { apiKey: 'first-key,second-key' } } },
        env: BARE_ENV,
        timeoutMs: 20_000,
      }),
    ).rejects.toThrow(/Every engine for the web source failed/);
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });

  it('does not try another key after a 5xx response, even when its body mentions quota', async () => {
    const fetchMock = vi.fn(async () => {
      return {
        ok: false,
        status: 503,
        statusText: 'Service Unavailable',
        text: async () => 'quota service temporarily unavailable',
      } as Response;
    });
    vi.stubGlobal('fetch', fetchMock);

    await expect(
      runSearch({
        query: 'q',
        engine: 'exa',
        config: { engines: { exa: { apiKey: 'first-key,second-key' } } },
        env: BARE_ENV,
        timeoutMs: 20_000,
      }),
    ).rejects.toThrow(/Every engine for the web source failed/);
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });

  it('does not treat unrelated 4xx wording as a quota failure', async () => {
    const fetchMock = vi.fn(async () => {
      return {
        ok: false,
        status: 400,
        statusText: 'Bad Request',
        text: async () => 'requested result count is out of range',
      } as Response;
    });
    vi.stubGlobal('fetch', fetchMock);

    await expect(
      runSearch({
        query: 'q',
        engine: 'exa',
        config: { engines: { exa: { apiKey: 'first-key,second-key' } } },
        env: BARE_ENV,
        timeoutMs: 20_000,
      }),
    ).rejects.toThrow(/Every engine for the web source failed/);
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });

  it('records quota cooldown only for the key that failed', async () => {
    const p = path.join(tempDir('modsearch-key-state-'), 'state.json');
    const now = new Date('2026-08-06T00:00:00.000Z');
    let call = 0;
    vi.stubGlobal(
      'fetch',
      vi.fn(async () => {
        call += 1;
        if (call === 1) {
          return {
            ok: false,
            status: 402,
            statusText: 'Payment Required',
            text: async () => 'insufficient balance for first-key and second-key',
          } as Response;
        }
        return {
          ok: true,
          status: 200,
          statusText: 'OK',
          json: async () => ({ results: [] }),
          text: async () => '{}',
        } as Response;
      }),
    );
    const controller = buildCooldownController({}, { now, statePath: p });

    await runSearch({
      query: 'q',
      engine: 'exa',
      config: { engines: { exa: { apiKey: 'first-key,second-key' } } },
      env: BARE_ENV,
      timeoutMs: 20_000,
      cooldown: controller,
    });

    const state = loadCooldownState(p);
    expect(state.engineCooldowns[cooldownStateKey('exa', 0)]).toBeDefined();
    expect(state.engineCooldowns[cooldownStateKey('exa', 1)]).toBeUndefined();
    expect(state.engineCooldowns.exa).toBeUndefined();
    const persisted = fs.readFileSync(p, 'utf-8');
    expect(persisted).not.toContain('first-key');
    expect(persisted).not.toContain('second-key');
  });

  it('tries healthy keys before a cooling key in the same engine', async () => {
    const p = path.join(tempDir('modsearch-key-order-'), 'state.json');
    const now = new Date('2026-08-06T00:00:00.000Z');
    recordQuotaCooldown(
      emptyCooldownState(),
      'exa',
      new Error('out of credits'),
      now,
      p,
      undefined,
      0,
    );
    const sentKeys: string[] = [];
    vi.stubGlobal(
      'fetch',
      vi.fn(async (_url: string, init: RequestInit) => {
        sentKeys.push((init.headers as Record<string, string>)['x-api-key']);
        return {
          ok: true,
          status: 200,
          statusText: 'OK',
          json: async () => ({ results: [] }),
          text: async () => '{}',
        } as Response;
      }),
    );

    const result = await runSearch({
      query: 'q',
      engine: 'exa',
      config: { engines: { exa: { apiKey: 'first-key,second-key' } } },
      env: BARE_ENV,
      timeoutMs: 20_000,
      cooldown: buildCooldownController({}, { now, statePath: p }),
    });

    expect(sentKeys).toEqual(['second-key']);
    expect(result.results[0].attempts).toMatchObject([{ keyIndex: 1, ok: true }]);
    expect(loadCooldownState(p).engineCooldowns[cooldownStateKey('exa', 0)]).toBeDefined();
  });
});

describeSpawn('a forced --engine is strict', () => {
  afterEach(() => cleanupTempDirs());

  it('errors instead of silently spending another engine when the forced one fails', async () => {
    // agy is forced and fails. A Tavily key is present, so the old behavior
    // would have quietly run Tavily (a real network call) and billed it. Strict
    // forcing must error here and never touch another engine.
    const config = agyConfig({ code: 1 }, { engines: { tavily: { apiKey: 'k' } } });
    await expect(
      runSearch({
        query: 'q',
        engine: 'antigravity-cli',
        config,
        env: BARE_ENV,
        timeoutMs: 20_000,
      }),
    ).rejects.toThrow(/Every engine for the web source failed/);
  }, 30_000);
});

describeSpawn('X degrade is labeled, never silently mislabeled', () => {
  afterEach(() => cleanupTempDirs());

  it('marks a web-served X answer as degraded web while keeping requestedSource x', async () => {
    // No Grok on this machine, so a web engine answers the X request. The entry
    // must not claim source "x": a consumer would read web hearsay as X data.
    const config = agyConfig({ stdout: agySearchEnvelope('web-sum') });
    const result = await runSearch({
      query: '推特上怎么说',
      sources: 'x',
      config,
      env: BARE_ENV,
      timeoutMs: 20_000,
    });
    expect(result.results).toHaveLength(1);
    const entry = result.results[0];
    expect(entry.source).toBe('web');
    expect(entry.requestedSource).toBe('x');
    expect(entry.status).toBe('degraded');
    expect(entry.engine).toBe('antigravity-cli');
    expect((entry.warnings as string[]).join(' ')).toContain('X itself was not reachable');
    // The degrade reason is a routing warning, not epistemic uncertainty.
    expect((entry.uncertainty as string[]).join(' ')).not.toContain('X itself was not reachable');
  }, 30_000);

  it('emits an explicit empty unavailable X entry for web,x when X is unreachable', async () => {
    const config = agyConfig({ stdout: agySearchEnvelope('web-sum') });
    const result = await runSearch({
      query: 'node lts',
      sources: 'web,x',
      config,
      env: BARE_ENV,
      timeoutMs: 20_000,
    });
    expect(result.results.map((r) => r.source)).toEqual(['web', 'x']);

    const web = result.results[0];
    expect(web.status).toBe('ok');
    expect(web.requestedSource).toBe('web');

    const x = result.results[1];
    expect(x.status).toBe('unavailable');
    expect(x.requestedSource).toBe('x');
    expect(x.engine).toBeNull();
    expect(x.items).toEqual([]);
    expect(x.attempts).toEqual([]);
    expect(x.uncertainty as string[]).toEqual([]);
    expect((x.warnings as string[]).join(' ')).toContain('X itself was not reachable');
  }, 30_000);
});

describeSpawn('multiple sources run concurrently and fail independently', () => {
  afterEach(() => cleanupTempDirs());

  /** A grok envelope carrying one canned structured result. */
  function grokEnvelope(summary: string): string {
    return JSON.stringify({
      structuredOutput: { summary, items: [], uncertainty: [] },
      sessionId: 's',
    });
  }

  it('runs web and X in parallel: total time is near the slower source, not the sum', async () => {
    // Each engine sleeps ~1s. Serial would be ~2s; concurrent is ~1s.
    const { env, restore } = withSignedInGrok();
    const agyBin = fakeEngine({ name: 'agy', stdout: agySearchEnvelope('web'), delaySeconds: 1 });
    const grokBin = fakeEngine({ name: 'grok', stdout: grokEnvelope('x'), delaySeconds: 1 });
    try {
      const result = await runSearch({
        query: 'anything',
        sources: 'web,x',
        config: {
          engine: 'antigravity-cli',
          engines: { 'antigravity-cli': { bin: agyBin }, 'grok-cli': { bin: grokBin } },
        },
        env,
        timeoutMs: 20_000,
      });
      expect(result.results.map((r) => r.source)).toEqual(['web', 'x']);
      expect(result.results.every((r) => r.status === 'ok')).toBe(true);
      // Serial execution would put this near 2s. Allow headroom for spawn cost.
      expect(result.meta.durationSeconds).toBeLessThan(1.8);
    } finally {
      restore();
      cleanupTempDirs();
    }
  }, 30_000);

  it('keeps a succeeding source when the other source fails entirely', async () => {
    // web has only a failing agy (no fallback); X is served by a working grok.
    // The web failure must not sink the run: it becomes an unavailable entry
    // while X still returns, and order stays web, x.
    const { env, restore } = withSignedInGrok();
    const agyBin = fakeEngine({ name: 'agy', code: 1 });
    const grokBin = fakeEngine({ name: 'grok', stdout: grokEnvelope('x-sum') });
    // Keyless firecrawl now closes the web chain; stub fetch so the unit test
    // stays offline and the web source genuinely exhausts its engines.
    vi.stubGlobal('fetch', async () => {
      throw new Error('offline unit test');
    });
    try {
      const result = await runSearch({
        query: 'anything',
        sources: 'web,x',
        config: {
          engine: 'antigravity-cli',
          engines: { 'antigravity-cli': { bin: agyBin }, 'grok-cli': { bin: grokBin } },
        },
        env,
        timeoutMs: 20_000,
      });
      expect(result.results.map((r) => r.source)).toEqual(['web', 'x']);

      const web = result.results[0];
      expect(web.status).toBe('unavailable');
      expect(web.engine).toBeNull();
      expect((web.attempts as Array<{ engine: string; ok: boolean }>)[0]).toMatchObject({
        engine: 'antigravity-cli',
        ok: false,
      });
      expect((web.warnings as string[]).join(' ')).toContain(
        'Every engine for the web source failed',
      );

      const x = result.results[1];
      expect(x.status).toBe('ok');
      expect(x.engine).toBe('grok-cli');
      expect(x.summary).toBe('x-sum');
    } finally {
      vi.unstubAllGlobals();
      restore();
      cleanupTempDirs();
    }
  }, 30_000);

  it('a single failing source still throws, so its behavior is unchanged', async () => {
    // Only web, and it fails: no other source to protect, so the run errors
    // exactly as before rather than returning an unavailable entry. Fetch is
    // stubbed so keyless firecrawl fails offline too.
    vi.stubGlobal('fetch', async () => {
      throw new Error('offline unit test');
    });
    try {
      const config = agyConfig({ code: 1 });
      await expect(
        runSearch({ query: 'anything', config, env: BARE_ENV, timeoutMs: 20_000 }),
      ).rejects.toThrow(/Every engine for the web source failed/);
    } finally {
      vi.unstubAllGlobals();
    }
  }, 30_000);
});

describeSpawn('a run deadline bounds the whole chain', () => {
  afterEach(() => {
    vi.unstubAllGlobals();
    cleanupTempDirs();
  });

  /** Run and hand back the SourceRunError a single failing source throws. */
  async function failedRun(options: Parameters<typeof runSearch>[0]) {
    return (await runSearch(options).catch((caught: unknown) => caught)) as Error & {
      attempts: EngineAttempt[];
    };
  }

  it('cuts a hung engine at the deadline and skips the engines after it', async () => {
    // agy would answer after 10s, inside its 20s per-engine budget. The 1.5s
    // run deadline must end it instead, and firecrawl must not start at all.
    const fetchCalls: unknown[] = [];
    vi.stubGlobal('fetch', async (...args: unknown[]) => {
      fetchCalls.push(args);
      throw new Error('firecrawl should not run once the deadline is spent');
    });
    const config = agyConfig({ stdout: agySearchEnvelope('late'), delaySeconds: 10 });
    const startedAt = Date.now();
    const error = await failedRun({
      query: 'anything',
      config,
      env: BARE_ENV,
      timeoutMs: 20_000,
      deadlineMs: 1_500,
    });

    // Without the deadline agy answers at 10s. The bound is loose on purpose.
    expect(Date.now() - startedAt).toBeLessThan(8_000);
    expect(error.message).toMatch(/Every engine for the web source failed/);
    expect(error.message).toMatch(/run deadline of 1500 ms/);
    expect(fetchCalls).toHaveLength(0);
    expect(error.attempts[0]).toMatchObject({ engine: 'antigravity-cli', ok: false });
    expect(error.attempts[1]).toMatchObject({
      engine: 'firecrawl',
      ok: false,
      durationSeconds: null,
      error: expect.stringMatching(/run deadline of 1500 ms/),
    });
  }, 20_000);

  it('gives the next engine only the time the deadline has left', async () => {
    // agy fails at once. firecrawl hangs until aborted: with a 20s per-engine
    // budget it would hold the run for 20s, so the deadline has to cap it.
    vi.stubGlobal('fetch', (_url: unknown, init: { signal: AbortSignal }) => {
      return new Promise((_resolve, reject) => {
        init.signal.addEventListener('abort', () => reject(new Error('aborted')));
      });
    });
    const config = agyConfig({ code: 1 });
    const error = await failedRun({
      query: 'anything',
      config,
      env: BARE_ENV,
      timeoutMs: 20_000,
      // Wide enough that a slow spawn of the failing agy still leaves firecrawl
      // a turn, short enough that 20s would plainly show the cap missing.
      deadlineMs: 6_000,
    });

    const firecrawl = error.attempts.find((attempt) => attempt.engine === 'firecrawl');
    const capped = Number(/timed out after (\d+) ms/.exec(firecrawl?.error ?? '')?.[1]);
    expect(capped).toBeGreaterThan(0);
    expect(capped).toBeLessThanOrEqual(6_000);
  }, 20_000);

  it('leaves the fallback room when a subprocess engine ignores its own timeout', async () => {
    // agy sleeps far past its 500ms timeout. Under a deadline the kill comes a
    // short grace after that timeout, not at the deadline, so firecrawl still
    // gets its turn inside the 10s run.
    vi.stubGlobal(
      'fetch',
      async () =>
        new Response(
          JSON.stringify({
            success: true,
            data: { web: [{ title: 'T', url: 'https://t.example', description: 'd' }] },
          }),
          { status: 200 },
        ),
    );
    const config = agyConfig({ stdout: agySearchEnvelope('late'), delaySeconds: 30 });
    const result = await runSearch({
      query: 'anything',
      config,
      env: BARE_ENV,
      timeoutMs: 500,
      deadlineMs: 10_000,
    });

    expect(result.results[0].engine).toBe('firecrawl');
    expect(result.results[0].attempts[0]).toMatchObject({ engine: 'antigravity-cli', ok: false });
  }, 20_000);

  it('counts the deadline from the moment the caller started it', async () => {
    // The CLI starts the clock at process start, so time spent before the run
    // (Node startup, config loading) comes out of the same budget.
    const config = agyConfig({ stdout: agySearchEnvelope('fast') });
    const error = await failedRun({
      query: 'anything',
      config,
      env: BARE_ENV,
      timeoutMs: 20_000,
      deadlineMs: 1_000,
      deadlineStartedAt: Date.now() - 2_000,
    });

    expect(error.attempts.length).toBeGreaterThan(0);
    expect(error.attempts.every((attempt) => attempt.durationSeconds === null)).toBe(true);
  }, 20_000);
});

describe('a run deadline holds over an in-process engine that overruns', () => {
  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('hands engines a whole-millisecond budget from a fractional clock', async () => {
    // performance.timeOrigin carries fractions, and AbortSignal.timeout throws
    // ERR_OUT_OF_RANGE on a fractional delay, so the budget must be whole.
    const firecrawl = findEngine('firecrawl') as Required<SearchEngine>;
    const seen: number[] = [];
    vi.spyOn(firecrawl, 'execute').mockImplementation(async (request) => {
      seen.push(request.timeoutMs);
      return {
        result: { summary: 's', items: [], uncertainty: [] },
        meta: { conversationId: null, durationSeconds: 0, usage: null },
      };
    });
    await runSearch({
      query: 'anything',
      engine: 'firecrawl',
      config: {},
      env: BARE_ENV,
      timeoutMs: 20_000,
      deadlineMs: 5_000,
      deadlineStartedAt: Date.now() + 0.375,
    });
    expect(seen).toHaveLength(1);
    expect(Number.isInteger(seen[0])).toBe(true);
  });

  it('stops waiting on the engine when the deadline falls', async () => {
    // A firecrawl that ignores its own timeout and never settles. The run must
    // still end at its deadline instead of waiting forever.
    const firecrawl = findEngine('firecrawl');
    if (!firecrawl?.execute) {
      throw new Error('firecrawl is expected to be an in-process engine');
    }
    vi.spyOn(firecrawl as Required<SearchEngine>, 'execute').mockImplementation(
      () => new Promise(() => {}),
    );
    const startedAt = Date.now();
    await expect(
      runSearch({
        query: 'anything',
        engine: 'firecrawl',
        config: {},
        env: BARE_ENV,
        timeoutMs: 20_000,
        deadlineMs: 300,
      }),
    ).rejects.toThrow(/firecrawl/);
    expect(Date.now() - startedAt).toBeLessThan(4_000);
  });
});

describe('uncertainty, warnings, and attempts are separate channels', () => {
  beforeEach(() => {
    vi.stubEnv('http_proxy', '');
    vi.stubEnv('https_proxy', '');
    vi.stubEnv('HTTP_PROXY', '');
    vi.stubEnv('HTTPS_PROXY', '');
    vi.stubEnv('no_proxy', '');
    vi.stubEnv('NO_PROXY', '');
  });

  afterEach(() => {
    cleanupTempDirs();
    vi.unstubAllEnvs();
  });

  itSpawn(
    'keeps the engine epistemic uncertainty, routing goes to warnings',
    async () => {
      // The engine reports a real gap; the run also falls back. The two must not
      // mix: uncertainty is the engine's own doubt, warnings is how we routed.
      const page = await startLocalPage('<html><body><p>fallback body here</p></body></html>');
      try {
        // agy fails on the first (config) engine, http answers the fetch.
        const config = agyConfig({ code: 1 }, { allowPrivateNetwork: true });
        const result = await runSearch({
          url: page.url,
          config,
          env: BARE_ENV,
          timeoutMs: 30_000,
        });
        const entry = result.results[0];
        expect(entry.engine).toBe('local');
        // the local engine's own uncertainty is epistemic only (nothing about routing here).
        expect((entry.uncertainty as string[]).join(' ')).not.toContain('Fell back');
        // Routing + runtime notices live in warnings.
        const warnings = (entry.warnings as string[]).join(' ');
        expect(warnings).toContain('Fell back to local');
        expect(warnings).toContain('no LLM synthesis');
      } finally {
        await page.close();
      }
    },
    40_000,
  );

  itSpawn(
    'records every engine attempt in order with per-try outcome',
    async () => {
      // agy fails, firecrawl and keenable decline the loopback target offline
      // (a reserved address never goes to the cloud), then local answers.
      const page = await startLocalPage(
        '<html><body><p>a body long enough to not look empty at all</p></body></html>',
      );
      try {
        const config = agyConfig({ code: 1 }, { allowPrivateNetwork: true });
        const result = await runSearch({ url: page.url, config, env: BARE_ENV, timeoutMs: 30_000 });
        const attempts = result.results[0].attempts as Array<{
          engine: string;
          ok: boolean;
          error?: string;
        }>;
        expect(attempts.map((a) => a.engine)).toEqual([
          'antigravity-cli',
          'firecrawl',
          'keenable',
          'local',
        ]);
        expect(attempts[0].ok).toBe(false);
        expect(typeof attempts[0].error).toBe('string');
        expect(attempts[1].ok).toBe(false);
        expect(attempts[1].error).toMatch(/private or reserved/);
        expect(attempts[2].ok).toBe(false);
        expect(attempts[2].error).toMatch(/keenable does not fetch the private or reserved/);
        expect(attempts[3].ok).toBe(true);
        expect(attempts[3].error).toBeUndefined();
      } finally {
        await page.close();
      }
    },
    40_000,
  );

  itSpawn(
    'scrubs token-shaped secrets from attempts and warnings',
    async () => {
      // A failing CLI's stderr loves to echo credentials. The final JSON travels
      // into terminals and model contexts, so no channel may carry the token.
      const secret = 'sk-leaked1234567890ABCDEF';
      const page = await startLocalPage(
        '<html><body><p>a body long enough to not look empty</p></body></html>',
      );
      try {
        const bin = fakeEngine({ name: 'agy', code: 1, stderr: `auth failed for ${secret}` });
        const config: ModsearchConfig = {
          engine: 'antigravity-cli',
          allowPrivateNetwork: true,
          engines: { 'antigravity-cli': { bin } },
        };
        const result = await runSearch({ url: page.url, config, env: BARE_ENV, timeoutMs: 30_000 });
        const rendered = JSON.stringify(result);
        expect(rendered).not.toContain(secret);
        // The scrub replaces rather than deletes, so the error stays actionable.
        expect(rendered).toContain('[redacted]');
      } finally {
        await page.close();
      }
    },
    40_000,
  );

  it('http sorts a thin page into uncertainty and its method notice into warnings', async () => {
    const page = await startLocalPage('<html><body>hi</body></html>');
    try {
      const result = await runSearch({
        url: page.url,
        config: { allowPrivateNetwork: true },
        env: BARE_ENV,
        timeoutMs: 30_000,
      });
      const entry = result.results[0];
      expect((entry.uncertainty as string[]).join(' ')).toContain('JavaScript');
      const warnings = (entry.warnings as string[]).join(' ');
      expect(warnings).toContain('Private network protection was disabled');
      expect(warnings).not.toContain('JavaScript');
    } finally {
      await page.close();
    }
  }, 40_000);
});

describeSpawn('quota cooldown records, clears, and can be switched off', () => {
  afterEach(() => cleanupTempDirs());
  const now = new Date('2026-08-06T00:00:00.000Z');
  const statePath = () => path.join(tempDir('modsearch-state-'), 'state.json');

  it('records a cooling engine when it fails with a quota error', async () => {
    const p = statePath();
    const config = agyConfig({ stdout: agyQuotaEnvelope() });
    const controller = buildCooldownController({}, { now, statePath: p });
    vi.stubGlobal('fetch', async () => {
      throw new Error('offline unit test');
    });
    await expect(
      runSearch({ query: 'q', config, env: BARE_ENV, timeoutMs: 20_000, cooldown: controller }),
    ).rejects.toThrow(/Every engine for the web source failed/);
    vi.unstubAllGlobals();
    // agy hit its quota, so it is remembered for the next run.
    const recorded = loadCooldownState(p).engineCooldowns['antigravity-cli'];
    expect(recorded).toBeDefined();
    expect(recorded.until).toBe(
      new Date(now.getTime() + (94 * 3600 + 19 * 60 + 9) * 1000).toISOString(),
    );
  }, 30_000);

  it('still tries a cooling engine, clears it on success, and warns', async () => {
    const p = statePath();
    // Seed: agy is already cooling from a prior run, so it is demoted this run.
    recordQuotaCooldown(
      emptyCooldownState(),
      'antigravity-cli',
      new Error('out of credits'),
      now,
      p,
    );
    const config = agyConfig({ stdout: agySearchEnvelope('back') });
    const controller = buildCooldownController({}, { now, statePath: p });
    // agy is demoted behind keyless firecrawl this run; stub fetch so
    // firecrawl fails offline and the demoted agy still gets its turn.
    vi.stubGlobal('fetch', async () => {
      throw new Error('offline unit test');
    });
    let result: Awaited<ReturnType<typeof runSearch>>;
    try {
      result = await runSearch({
        query: 'q',
        config,
        env: BARE_ENV,
        timeoutMs: 20_000,
        cooldown: controller,
      });
    } finally {
      vi.unstubAllGlobals();
    }
    // It was the only engine, so demoted-not-removed means it is still tried and
    // answers. A successful answer clears its cooldown.
    expect(result.results[0].engine).toBe('antigravity-cli');
    expect(result.results[0].summary).toBe('back');
    expect(loadCooldownState(p).engineCooldowns['antigravity-cli']).toBeUndefined();
    expect((result.results[0].warnings as string[]).join(' ')).toMatch(/cooling until/);
  }, 30_000);

  it('reads and writes nothing when the switch is off', async () => {
    const p = statePath();
    const config = agyConfig({ stdout: agyQuotaEnvelope() }, { cooldown: 'off' });
    const controller = buildCooldownController(config, { now, statePath: p });
    expect(controller).toBeUndefined();
    vi.stubGlobal('fetch', async () => {
      throw new Error('offline unit test');
    });
    await expect(
      runSearch({ query: 'q', config, env: BARE_ENV, timeoutMs: 20_000, cooldown: controller }),
    ).rejects.toThrow(/Every engine/);
    vi.unstubAllGlobals();
    // Off means the state file is never created.
    expect(fs.existsSync(p)).toBe(false);
  }, 30_000);
});

describe('engine spend surfaces on the attempt', () => {
  afterEach(() => {
    vi.unstubAllGlobals();
    vi.restoreAllMocks();
    cleanupTempDirs();
  });

  /** Stub the global fetch with one JSON response, for the in-process engines. */
  function stubFetchJson(body: unknown) {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () => ({
        ok: true,
        status: 200,
        statusText: 'OK',
        json: async () => body,
        text: async () => JSON.stringify(body),
      })),
    );
  }

  const firstAttempt = (result: Awaited<ReturnType<typeof runSearch>>) =>
    (result.results[0].attempts as EngineAttempt[])[0];

  it('carries exa dollar cost onto the attempt, and no credits', async () => {
    stubFetchJson({
      results: [{ title: 'A', url: 'https://a.example.com/p', highlights: ['h'] }],
      costDollars: { total: 0.007 },
    });
    const result = await runSearch({
      query: 'q',
      engine: 'exa',
      config: { engines: { exa: { apiKey: 'k' } } },
      env: BARE_ENV,
      timeoutMs: 20_000,
    });
    const attempt = firstAttempt(result);
    expect(attempt).toMatchObject({ engine: 'exa', ok: true, cost: 0.007 });
    expect(attempt.keyIndex).toBeUndefined();
    expect(attempt.credits).toBeUndefined();
  });

  it('carries firecrawl credits onto the attempt, and no cost', async () => {
    stubFetchJson({
      success: true,
      data: { web: [{ title: 'A', url: 'https://a.example.com/p', description: 'd' }] },
      creditsUsed: 3,
    });
    const result = await runSearch({
      query: 'q',
      engine: 'firecrawl',
      config: { engines: { firecrawl: { apiKey: 'k' } } },
      env: BARE_ENV,
      timeoutMs: 20_000,
    });
    const attempt = firstAttempt(result);
    expect(attempt).toMatchObject({ engine: 'firecrawl', ok: true, credits: 3 });
    expect(attempt.cost).toBeUndefined();
  });
});

describeSpawn('routing facts cannot be faked by an engine', () => {
  afterEach(() => cleanupTempDirs());

  it('overwrites source, engine, and model even when the engine has no model', async () => {
    // A conditional spread left `model` writable whenever the engine's default
    // model was empty, so a result could claim to come from somewhere else.
    const config = agyConfig({
      stdout:
        '{"status":"SUCCESS","structured_output":{"summary":"s","items":[],"uncertainty":[],"source":"x","engine":"spoofed","model":"spoof-model","durationSeconds":999}}',
    });
    const result = await runSearch({
      query: 'plain query',
      config,
      env: BARE_ENV,
      timeoutMs: 20_000,
    });
    expect(result.results[0].source).toBe('web');
    expect(result.results[0].engine).toBe('antigravity-cli');
    expect(result.results[0].model).toBe('gemini-3.8-flash-low');
    expect(result.results[0].durationSeconds).toBeLessThan(100);
  }, 30_000);
});

import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { classifyQuota } from '../cooldown.ts';
import { runSearch } from '../search.ts';
import { BARE_ENV } from '../testing/helpers.ts';
import { executeFirecrawl, looksLikeClientRenderedShell } from './firecrawl.ts';
import { resolveEngine } from './index.ts';

// Mock DNS so the fake-ip case (a public-looking host that resolves to a
// reserved IP) is testable offline. Literal-IP targets never reach it.
const { lookupMock } = vi.hoisted(() => ({ lookupMock: vi.fn() }));
vi.mock('dns/promises', () => ({ lookup: lookupMock }));

beforeEach(() => {
  lookupMock.mockReset();
  // Default: an incidental lookup resolves to a public IP. Only the tests that
  // opt in resolve to a reserved one.
  lookupMock.mockResolvedValue([{ address: '93.184.216.34', family: 4 }]);
});

afterEach(() => {
  vi.restoreAllMocks();
});

/** Mock the global fetch with a JSON response, capturing each request. */
function mockFetchJson(
  body: unknown,
  init: { ok?: boolean; status?: number; text?: string; headers?: Record<string, string> } = {},
) {
  const calls: Array<{ url: string; init: RequestInit }> = [];
  const fn = vi.fn(async (url: string, requestInit: RequestInit) => {
    calls.push({ url, init: requestInit });
    return {
      ok: init.ok ?? true,
      status: init.status ?? 200,
      statusText: 'OK',
      headers: new Headers(init.headers),
      json: async () => body,
      text: async () => init.text ?? JSON.stringify(body),
    } as unknown as Response;
  });
  vi.stubGlobal('fetch', fn);
  return calls;
}

describe('looksLikeClientRenderedShell', () => {
  it('recognizes the issue #29 shared-page shell', () => {
    const markdown = '[Skip to content](#main)\n\n## Chat history';
    expect(looksLikeClientRenderedShell(markdown)).toBe(true);
  });

  it.each([
    [
      'two links and an empty section',
      '[Contents](#main)\n[Account](/account)\n\n## Conversation',
      true,
    ],
    ['two links without targets', '[Contents]\n[Account]\n\n## Conversation', true],
    ['link list without body', '# App\n\n- [Library](/library)\n- [Profile](/profile)', true],
    ['inline links without body', '[Library](/library) | [Profile](/profile)', true],
    ['links only within headings', '# [Library](/library)\n\n## [Profile](/profile)', false],
    ['Chinese shell', '[跳转正文](#main)\n\n## 会话记录', true],
    ['empty markdown', '', false],
    ['headings alone', '# Title\n\n## Chat history', false],
    [
      'one link without a target and an empty section',
      '[Skip to content]\n\n## Chat history',
      true,
    ],
    ['one link without body', '[Library](/library)', true],
    ['link collection without body', '# Resources\n\n[Guide](/guide)\n[API reference](/api)', true],
    [
      'short body alongside multiple links',
      '[状态](/status) | [详情](/details)\n\n# 系统状态\n\n系统运行正常。',
      false,
    ],
  ])('classifies %s', (_name, markdown, expected) => {
    expect(looksLikeClientRenderedShell(markdown)).toBe(expected);
  });
});

describe('firecrawl provider registration', () => {
  it('resolves by name and serves both search and fetch', () => {
    const engine = resolveEngine('firecrawl');
    expect(engine.name).toBe('firecrawl');
    expect(engine.roles).toEqual(['search', 'fetch']);
    expect(engine.execute).toBeTypeOf('function');
    expect(engine.buildInvocation).toBeUndefined();
    expect(engine.isAvailable({}, {}, 'search')).toBe(true);
    // Keyless fetch is on by default; only an explicit false turns it off.
    expect(engine.isAvailable({}, {}, 'fetch')).toBe(true);
    expect(engine.isAvailable({ keylessFetch: true }, {}, 'fetch')).toBe(true);
    expect(engine.isAvailable({ keylessFetch: false }, {}, 'fetch')).toBe(false);
    // Malformed values fail closed: no cloud disclosure on a guess. (Config
    // loading normalizes hand-written strings before they get here.)
    expect(engine.isAvailable({ keylessFetch: 'false' as unknown as boolean }, {}, 'fetch')).toBe(
      false,
    );
    expect(engine.isAvailable({ keylessFetch: 'true' as unknown as boolean }, {}, 'fetch')).toBe(
      false,
    );
    // An API key enables fetch regardless of the switch.
    expect(engine.isAvailable({ keylessFetch: false, apiKey: 'fc-x' }, {}, 'fetch')).toBe(true);
  });
});

describe('firecrawl search path', () => {
  it('searches keyless, sending no authorization header without a key', async () => {
    const calls = mockFetchJson({ success: true, data: { web: [] } });
    await executeFirecrawl({ mode: 'search', query: 'anything', timeoutMs: 1000, settings: {} });
    expect(calls).toHaveLength(1);
    const headers = calls[0].init.headers as Record<string, string>;
    expect(headers.authorization).toBeUndefined();
  });

  it('sends the Bearer key when one is configured', async () => {
    const calls = mockFetchJson({ success: true, data: { web: [] } });
    await executeFirecrawl({
      mode: 'search',
      query: 'anything',
      timeoutMs: 1000,
      settings: { apiKey: 'fc-test' },
    });
    const headers = calls[0].init.headers as Record<string, string>;
    expect(headers.authorization).toBe('Bearer fc-test');
  });

  it('fetches keyless, sending no authorization header without a key', async () => {
    const calls = mockFetchJson({
      success: true,
      data: { markdown: '# Example', links: [], metadata: { statusCode: 200 } },
    });
    await executeFirecrawl({
      mode: 'fetch',
      url: 'https://example.com/',
      timeoutMs: 1000,
      settings: {},
    });
    expect(calls).toHaveLength(1);
    const headers = calls[0].init.headers as Record<string, string>;
    expect(headers.authorization).toBeUndefined();
  });

  it('posts to the v2 search endpoint with a Bearer key and the search body', async () => {
    const calls = mockFetchJson({ success: true, data: { web: [] }, creditsUsed: 2 });
    await executeFirecrawl({
      mode: 'search',
      query: 'v2 contract',
      maxResults: 10,
      timeoutMs: 30000,
      settings: { apiKey: 'fc-test' },
    });
    expect(calls).toHaveLength(1);
    expect(calls[0].url).toBe('https://api.firecrawl.dev/v2/search');
    expect(calls[0].init.method).toBe('POST');
    const headers = calls[0].init.headers as Record<string, string>;
    expect(headers.authorization).toBe('Bearer fc-test');
    const sent = JSON.parse(calls[0].init.body as string);
    expect(sent.query).toBe('v2 contract');
    expect(sent.limit).toBe(10);
    expect(sent.sources).toEqual(['web']);
    expect(sent.timeout).toBeGreaterThan(0);
    expect(calls[0].init.signal).toBeInstanceOf(AbortSignal);
  });

  it('posts both roles to a configured baseURL, trailing slash folded', async () => {
    const searchCalls = mockFetchJson({ success: true, data: { web: [] } });
    await executeFirecrawl({
      mode: 'search',
      query: 'q',
      timeoutMs: 30000,
      settings: { baseURL: 'https://gw.example.com/fc/' },
    });
    expect(searchCalls[0].url).toBe('https://gw.example.com/fc/v2/search');

    const scrapeCalls = mockFetchJson({
      success: true,
      data: { markdown: '# t', links: [], metadata: { statusCode: 200 } },
    });
    await executeFirecrawl({
      mode: 'fetch',
      url: 'http://93.184.216.34/page',
      timeoutMs: 30000,
      settings: { apiKey: 'fc-test', baseURL: 'https://gw.example.com/fc' },
    });
    expect(scrapeCalls[0].url).toBe('https://gw.example.com/fc/v2/scrape');
  });

  it('maps web results into the search contract with description as snippet', async () => {
    mockFetchJson({
      success: true,
      data: {
        web: [
          { title: 'A', description: 'desc a', url: 'https://a.example.com/p' },
          { title: 'B', description: 'desc b', url: 'not a url' },
        ],
      },
      creditsUsed: 2,
    });
    const parsed = await executeFirecrawl({
      mode: 'search',
      query: 'q',
      timeoutMs: 30000,
      settings: { apiKey: 'fc-test' },
    });
    const result = parsed.result as {
      summary: string;
      items: Array<Record<string, unknown>>;
      uncertainty: string[];
      warnings: string[];
    };
    expect(result.items).toEqual([
      { title: 'A', url: 'https://a.example.com/p', snippet: 'desc a', source: 'a.example.com' },
      { title: 'B', url: 'not a url', snippet: 'desc b', source: undefined },
    ]);
    expect(result.warnings.join(' ')).toMatch(/read items|without.*summary|no.*synthes/i);
    expect(result.uncertainty).toEqual([]);
  });

  it('reports an empty search result set as uncertainty', async () => {
    mockFetchJson({ success: true, data: { web: [] } });
    const parsed = await executeFirecrawl({
      mode: 'search',
      query: 'nothing',
      timeoutMs: 30000,
      settings: { apiKey: 'fc-test' },
    });
    const result = parsed.result as { items: unknown[]; uncertainty: string[] };
    expect(result.items).toEqual([]);
    expect(result.uncertainty.join(' ')).toMatch(/No results/i);
  });

  it('aborts the underlying request on timeout and reports it', async () => {
    let sawAbort = false;
    const fn = vi.fn(
      (_url: string, init: RequestInit) =>
        new Promise<Response>((_resolve, reject) => {
          init.signal?.addEventListener('abort', () => {
            sawAbort = true;
            reject(new DOMException('The operation was aborted.', 'AbortError'));
          });
        }),
    );
    vi.stubGlobal('fetch', fn);
    await expect(
      executeFirecrawl({
        mode: 'search',
        query: 'q',
        timeoutMs: 20,
        settings: { apiKey: 'fc-test' },
      }),
    ).rejects.toThrow(/firecrawl timed out after 20 ms/);
    expect(sawAbort).toBe(true);
  });

  it('keeps the timeout armed while the response body streams', async () => {
    // Headers arrive at once, then the body never finishes: only an abort that
    // is still armed after the headers can end the read.
    vi.stubGlobal('fetch', async (_url: string, init: RequestInit) => ({
      ok: true,
      status: 200,
      statusText: 'OK',
      text: () =>
        new Promise<string>((_resolve, reject) => {
          init.signal?.addEventListener('abort', () =>
            reject(new DOMException('The operation was aborted.', 'AbortError')),
          );
        }),
      json: () => new Promise(() => {}),
    }));

    await expect(
      executeFirecrawl({
        mode: 'search',
        query: 'q',
        timeoutMs: 20,
        settings: { apiKey: 'fc-test' },
      }),
    ).rejects.toThrow(/firecrawl timed out after 20 ms/);
  });
});

describe('firecrawl fetch path', () => {
  it('fetches a public hostname when local DNS returns a Surge-style fake IP', async () => {
    lookupMock.mockResolvedValue([{ address: '198.18.92.141', family: 4 }]);
    const calls = mockFetchJson({
      success: true,
      data: {
        markdown: '# Node.js releases',
        links: [],
        metadata: { statusCode: 200 },
      },
    });

    await expect(
      executeFirecrawl({
        mode: 'fetch',
        url: 'https://nodejs.org/en/about/previous-releases',
        timeoutMs: 30000,
        settings: { apiKey: 'fc-test' },
      }),
    ).resolves.toBeDefined();
    expect(calls).toHaveLength(1);
  });

  it('fetches when dual-stack DNS returns a fake IPv4 and a public IPv6 address', async () => {
    lookupMock.mockResolvedValue([
      { address: '198.18.92.141', family: 4 },
      { address: '2606:4700::6810:d583', family: 6 },
    ]);
    const calls = mockFetchJson({
      success: true,
      data: { markdown: '# Node.js releases', links: [], metadata: { statusCode: 200 } },
    });

    await expect(
      executeFirecrawl({
        mode: 'fetch',
        url: 'https://nodejs.org/en/about/previous-releases',
        timeoutMs: 30000,
        settings: { apiKey: 'fc-test' },
      }),
    ).resolves.toBeDefined();
    expect(calls).toHaveLength(1);
  });

  it('fetches when DNS returns both a private address and a real public address', async () => {
    lookupMock.mockResolvedValue([
      { address: '10.1.2.3', family: 4 },
      { address: '93.184.216.34', family: 4 },
    ]);
    const calls = mockFetchJson({
      success: true,
      data: { markdown: '# Public route', links: [], metadata: { statusCode: 200 } },
    });

    await expect(
      executeFirecrawl({
        mode: 'fetch',
        url: 'https://mixed.example.com/page',
        timeoutMs: 30000,
        settings: { apiKey: 'fc-test' },
      }),
    ).resolves.toBeDefined();
    expect(calls).toHaveLength(1);
  });

  it('posts to the v2 scrape endpoint and maps markdown, links, and metadata', async () => {
    const links = Array.from({ length: 25 }, (_, i) => `https://a.example.com/l${i}`);
    const calls = mockFetchJson({
      success: true,
      data: {
        markdown: '# Title\n\nBody text long enough to not look empty at all here.',
        links,
        metadata: {
          title: 'Title',
          description: 'desc',
          statusCode: 200,
          sourceURL: 'https://93.184.216.34/page',
        },
      },
    });
    // A public IP literal so the reserved-target check needs no DNS.
    const parsed = await executeFirecrawl({
      mode: 'fetch',
      url: 'http://93.184.216.34/page',
      timeoutMs: 30000,
      settings: { apiKey: 'fc-test' },
    });
    expect(calls[0].url).toBe('https://api.firecrawl.dev/v2/scrape');
    const sent = JSON.parse(calls[0].init.body as string);
    expect(sent.url).toBe('http://93.184.216.34/page');
    expect(sent.formats).toEqual(['markdown', 'links']);
    expect(sent.onlyMainContent).toBe(true);
    expect(sent.timeout).toBeGreaterThan(0);
    // Force fresh: no Firecrawl cache, so stale content can never come back.
    expect(sent.maxAge).toBe(0);
    // The API defaults storeInCache and skipTlsVerification to true, so both
    // must be sent explicitly: scraped pages stay out of Firecrawl's index,
    // and certificate checks stay on.
    expect(sent.storeInCache).toBe(false);
    expect(sent.skipTlsVerification).toBe(false);

    const result = parsed.result as {
      summary: string;
      content: string;
      links: Array<{ text: string; url: string }>;
      uncertainty: string[];
      warnings: string[];
    };
    expect(result.content).toContain('Body text');
    // Links are trimmed to 20 to match the http engine.
    expect(result.links).toHaveLength(20);
    expect(result.links[0]).toEqual({
      text: 'https://a.example.com/l0',
      url: 'https://a.example.com/l0',
    });
    expect(result.summary).toContain('Title');
    expect(result.warnings.join(' ')).toMatch(/Firecrawl|JavaScript|cloud/i);
    // Content under the cap is never flagged as truncated.
    expect(result.warnings.join(' ')).not.toMatch(/truncated/i);
  });

  it('reports the issue #29 shell while keeping one successful Firecrawl attempt', async () => {
    const markdown = '[Skip to content](#main)\n\n## Chat history';
    const calls = mockFetchJson({
      success: true,
      data: {
        markdown,
        links: [],
        metadata: { title: 'Shared conversation', statusCode: 200 },
      },
    });
    const parsed = await runSearch({
      url: 'https://chatgpt.com/share/test',
      timeoutMs: 30000,
      config: { engines: { firecrawl: { apiKey: 'fc-test' } } },
      env: BARE_ENV,
    });

    expect(parsed.results).toHaveLength(1);
    expect(parsed.results[0]).toMatchObject({
      engine: 'firecrawl',
      status: 'ok',
      content: markdown,
      uncertainty: [
        'The page content is likely generated by browser-side JavaScript, but this fetch captured only the page shell. Missing content does not mean the page itself is empty.',
      ],
      attempts: [{ engine: 'firecrawl', ok: true }],
    });
    expect(calls).toHaveLength(1);
    expect(JSON.parse(calls[0].init.body as string).formats).toEqual(['markdown', 'links']);
  });

  it('keeps the sparse-page uncertainty for a short page with actual body text', async () => {
    const markdown = '[Skip to content](#main)\n\n# Status\n\nAll systems operational.';
    mockFetchJson({
      success: true,
      data: { markdown, links: [], metadata: { statusCode: 200 } },
    });
    const parsed = await executeFirecrawl({
      mode: 'fetch',
      url: 'http://93.184.216.34/status',
      timeoutMs: 30000,
      settings: { apiKey: 'fc-test' },
    });

    expect(parsed.result).toMatchObject({
      content: markdown,
      uncertainty: [
        'Very little content came back from Firecrawl, so the page may be genuinely sparse.',
      ],
    });
  });

  it('adds no thin-content uncertainty for a normal page with navigation and body text', async () => {
    const markdown = [
      '[Skip to content](#main)',
      '# Release notes',
      'This release adds a search command and a page reader. Both return structured evidence with source links.',
      'The page reader preserves markdown headings and paragraphs so callers can inspect the available content.',
    ].join('\n\n');
    expect(markdown.length).toBeGreaterThanOrEqual(200);
    mockFetchJson({
      success: true,
      data: { markdown, links: [], metadata: { statusCode: 200 } },
    });
    const parsed = await executeFirecrawl({
      mode: 'fetch',
      url: 'http://93.184.216.34/releases',
      timeoutMs: 30000,
      settings: { apiKey: 'fc-test' },
    });

    expect(parsed.result).toMatchObject({ content: markdown, uncertainty: [] });
  });

  it('caps oversized markdown at the shared 50000-char limit and warns', async () => {
    const huge = 'x'.repeat(60_000);
    mockFetchJson({
      success: true,
      data: { markdown: huge, links: [], metadata: { statusCode: 200 } },
    });
    const parsed = await executeFirecrawl({
      mode: 'fetch',
      url: 'http://93.184.216.34/big',
      timeoutMs: 30000,
      settings: { apiKey: 'fc-test' },
    });
    const result = parsed.result as { content: string; warnings: string[] };
    expect(result.content).toHaveLength(50_000);
    expect(result.warnings.join(' ')).toMatch(/truncated at 50000 characters/i);
  });

  it('treats a non-2xx page statusCode as a failure', async () => {
    mockFetchJson({
      success: true,
      data: {
        markdown: '',
        links: [],
        metadata: { statusCode: 404, sourceURL: 'http://93.184.216.34/x' },
      },
    });
    await expect(
      executeFirecrawl({
        mode: 'fetch',
        url: 'http://93.184.216.34/x',
        timeoutMs: 30000,
        settings: { apiKey: 'fc-test' },
      }),
    ).rejects.toThrow(/404/);
  });

  it('skips a literal private target without calling the API', async () => {
    const calls = mockFetchJson({ success: true, data: {} });
    await expect(
      executeFirecrawl({
        mode: 'fetch',
        url: 'http://192.168.1.10/admin',
        timeoutMs: 30000,
        settings: { apiKey: 'fc-test' },
      }),
    ).rejects.toThrow(/private or reserved.*Use the local engine instead/i);
    // The cloud crawler was never contacted for a private address.
    expect(calls).toHaveLength(0);
  });

  it('still skips a literal private target even when the private network is allowed', async () => {
    // The leak fix: a private IP written straight into the URL is never handed to
    // the cloud, switch or not, so an internal address cannot leak to Firecrawl.
    const calls = mockFetchJson({ success: true, data: {} });
    await expect(
      executeFirecrawl({
        mode: 'fetch',
        url: 'http://10.0.0.5/admin',
        timeoutMs: 30000,
        settings: { apiKey: 'fc-test' },
        allowPrivateNetwork: true,
      }),
    ).rejects.toThrow(/private|reserved/i);
    expect(calls).toHaveLength(0);
    expect(lookupMock).not.toHaveBeenCalled();
  });

  it('rejects a truly private-resolving host with its address and a fake-IP hint', async () => {
    // The switch authorizes local access to private addresses. It never
    // authorizes handing the hostname and path to a third-party crawler.
    lookupMock.mockResolvedValue([{ address: '10.1.2.3', family: 4 }]);
    const calls = mockFetchJson({
      success: true,
      data: {
        markdown: 'ok content here that is long enough',
        links: [],
        metadata: { statusCode: 200 },
      },
    });
    await expect(
      executeFirecrawl({
        mode: 'fetch',
        url: 'http://internal.example.com/admin',
        timeoutMs: 30000,
        settings: { apiKey: 'fc-test' },
        allowPrivateNetwork: true,
      }),
    ).rejects.toThrow(/internal\.example\.com -> 10\.1\.2\.3.*fake-IP/i);
    expect(calls).toHaveLength(0);
  });

  it('rejects a hostname when every resolved address is private and lists them all', async () => {
    lookupMock.mockResolvedValue([
      { address: '10.1.2.3', family: 4 },
      { address: '192.168.1.9', family: 4 },
    ]);
    const calls = mockFetchJson({ success: true, data: {} });
    await expect(
      executeFirecrawl({
        mode: 'fetch',
        url: 'http://internal.example.com/admin',
        timeoutMs: 30000,
        settings: { apiKey: 'fc-test' },
      }),
    ).rejects.toThrow(/10\.1\.2\.3, 192\.168\.1\.9.*fake-IP/i);
    expect(calls).toHaveLength(0);
    expect(lookupMock).toHaveBeenCalled();
  });
});

describe('firecrawl error classification', () => {
  it('uses only the first configured key and redacts every configured key from errors', async () => {
    const first = 'alpha-plain-secret';
    const second = 'bravo-plain-secret';
    const calls = mockFetchJson(
      { error: 'unauthorized' },
      {
        ok: false,
        status: 401,
        text: `${first} was rejected, then ${second} was echoed`,
      },
    );
    let error: Error | undefined;
    try {
      await executeFirecrawl({
        mode: 'search',
        query: 'q',
        timeoutMs: 30_000,
        settings: { apiKey: `${first}, ${second}` },
      });
    } catch (caught) {
      error = caught as Error;
    }

    expect((calls[0].init.headers as Record<string, string>).authorization).toBe(`Bearer ${first}`);
    expect(error?.message).not.toContain(first);
    expect(error?.message).not.toContain(second);
  });

  it('recognizes a 402 or credits-exhausted response as a quota error', async () => {
    mockFetchJson(
      { error: 'Payment Required: insufficient credits' },
      { ok: false, status: 402, text: 'insufficient credits' },
    );
    await expect(
      executeFirecrawl({
        mode: 'search',
        query: 'q',
        timeoutMs: 30000,
        settings: { apiKey: 'fc-test' },
      }),
    ).rejects.toThrow(/credit|quota|payment/i);
  });

  it('treats 401 as a key problem with a config-set fix', async () => {
    mockFetchJson({ error: 'unauthorized' }, { ok: false, status: 401, text: 'unauthorized' });
    await expect(
      executeFirecrawl({
        mode: 'search',
        query: 'q',
        timeoutMs: 30000,
        settings: { apiKey: 'bad' },
      }),
    ).rejects.toThrow(/config set firecrawl\.apiKey/);
  });

  it('explains a keyless 401 without claiming an API key was rejected', async () => {
    mockFetchJson({ error: 'unauthorized' }, { ok: false, status: 401, text: 'unauthorized' });
    const request = executeFirecrawl({
      mode: 'search',
      query: 'q',
      timeoutMs: 30000,
      settings: {},
    });
    await expect(request).rejects.toThrow(/keyless request/);
    await expect(request).rejects.not.toThrow(/rejected the API key/);
  });

  it('says plainly when Firecrawl refuses keyless access from a proxy or VPN exit', async () => {
    const body =
      '{"success":false,"error":"Unfortunately, your IP address looks like a VPN or proxy, so Firecrawl can\'t be used without an API key from here."}';
    mockFetchJson({}, { ok: false, status: 403, text: body });
    const request = executeFirecrawl({
      mode: 'search',
      query: 'q',
      timeoutMs: 30000,
      settings: {},
    });
    await expect(request).rejects.toThrow(
      /firecrawl does not allow keyless use from a proxy or VPN exit IP\. Set a free key: modsearch config set firecrawl\.apiKey <key>, or use keenable or youcom\./,
    );
  });
});

describe('a spent keyless allowance', () => {
  const now = new Date('2026-11-15T14:00:00.000Z');

  it('names the reset time so the cooldown holds Firecrawl until then', async () => {
    // The live body Firecrawl sends once an IP's keyless credits are gone.
    const body =
      '{"success":false,"error":"You\'ve hit Firecrawl\'s keyless free tier rate limit. To continue now, create a free API key","reason":"credits","retry_after_seconds":85732}';
    mockFetchJson({}, { ok: false, status: 429, text: body, headers: { 'retry-after': '85731' } });
    const error = await executeFirecrawl({
      mode: 'search',
      query: 'q',
      timeoutMs: 30000,
      settings: {},
    }).catch((caught: unknown) => caught);
    expect((error as Error).message).toMatch(
      /keyless allowance for this IP is used up\. Resets in 23h48m52s\. Set a free key: modsearch config set firecrawl\.apiKey <key>, or use keenable or youcom\./,
    );
    expect(classifyQuota(error, now)?.getTime()).toBe(now.getTime() + 85732 * 1000);
  });

  it('falls back to the Retry-After header when the body has no seconds', async () => {
    const body = '{"success":false,"error":"rate limit","reason":"credits"}';
    mockFetchJson({}, { ok: false, status: 429, text: body, headers: { 'retry-after': '3600' } });
    const error = await executeFirecrawl({
      mode: 'search',
      query: 'q',
      timeoutMs: 30000,
      settings: {},
    }).catch((caught: unknown) => caught);
    expect(classifyQuota(error, now)?.getTime()).toBe(now.getTime() + 3600 * 1000);
  });

  it('leaves a short burst limit transient, so nothing is remembered', async () => {
    const body = '{"success":false,"error":"Too many requests, slow down"}';
    mockFetchJson({}, { ok: false, status: 429, text: body, headers: { 'retry-after': '5' } });
    const error = await executeFirecrawl({
      mode: 'search',
      query: 'q',
      timeoutMs: 30000,
      settings: {},
    }).catch((caught: unknown) => caught);
    expect(classifyQuota(error, now)).toBeNull();
  });
});

describe('timeout clamping', () => {
  it('clamps the requested timeout to the documented 1000-300000 ms contract', async () => {
    const calls = mockFetchJson({ success: true, data: { web: [] } });
    await executeFirecrawl({
      mode: 'search',
      query: 'q',
      timeoutMs: 200,
      settings: { apiKey: 'fc-test' },
    });
    const sent = JSON.parse(calls[0].init.body as string);
    expect(sent.timeout).toBe(1000);
  });
});
